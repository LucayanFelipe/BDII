CREATE DATABASE Multa;
USE Multa;

CREATE TABLE IF NOT EXISTS Estado (
	id_estado INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    sigla VARCHAR(50) NOT NULL,
    nome_pais VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS Cidade (
	id_cidade INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    codigo_ibge VARCHAR(10) NOT NULL,
    fk_estado_id INT NOT NULL,
	FOREIGN KEY (fk_estado_id) REFERENCES Estado (id_estado)
);

CREATE TABLE IF NOT EXISTS Endereco (
	id_endereco INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    cep VARCHAR(9) NOT NULL,
    logradouro VARCHAR(30) NOT NULL,
    bairro VARCHAR(30) NOT NULL,
    numero VARCHAR(6),
    fk_cidade_id INT NOT NULL,
    FOREIGN KEY (fk_cidade_id) REFERENCES Cidade (id_cidade)
);

CREATE TABLE IF NOT EXISTS Marca (
	id_marca INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    observacao VARCHAR(200),
    localidade VARCHAR(30) NOT NULL
);

CREATE TABLE IF NOT EXISTS Modelo (
	id_modelo INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    descricao VARCHAR(100),
    qtd_eixos INT NOT NULL,
    peso DOUBLE NOT NULL,
    qtd_passageiros INT NOT NULL,
    cavalaria FLOAT NOT NULL,
    cilindradas FLOAT NOT NULL,
    fk_marca_id INT NOT NULL,
    FOREIGN KEY (fk_marca_id) REFERENCES Marca (id_marca)
);

CREATE TABLE IF NOT EXISTS Proprietario (
	id_proprietario INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    email VARCHAR(60) UNIQUE NOT NULL,
    telefone VARCHAR(14),
    fk_endereco_id INT NOT NULL,
    FOREIGN KEY (fk_endereco_id) REFERENCES Endereco (id_endereco)
);

CREATE TABLE IF NOT EXISTS Proprietario_PF (
	id_proprietariopf INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    cpf VARCHAR(11) UNIQUE NOT NULL,
    rg VARCHAR(9) NOT NULL,
    data_nascimento DATE NOT NULL,
    sexo ENUM ('masculino', 'feminino', 'outros') NOT NULL,
    id_proprietario_fk INT,
    FOREIGN KEY (id_proprietario_fk) REFERENCES Proprietario(id_proprietario) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Proprietario_PJ (
	id_proprietariopj INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    cnpj VARCHAR(50) NOT NULL,
    nome_fantasia VARCHAR(50) NOT NULL,
    situacao ENUM ('ativa','inativa') NOT NULL,
    atividade_economica VARCHAR(50) NOT NULL,
    inscricao_estadual VARCHAR(9) NOT NULL,
    id_proprietario_fk INT,
    FOREIGN KEY (id_proprietario_fk) REFERENCES Proprietario(id_proprietario) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Cnh (
	id_cnh INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    data_emissao DATE NOT NULL,
    data_vencimento DATE NOT NULL,
    categoria VARCHAR(6) NOT NULL,
    pontuacao INT NOT NULL,
    numero VARCHAR(10) NOT NULL,
    fk_proprietarioPF_id int,
    FOREIGN KEY (fk_proprietarioPF_id) REFERENCES Proprietario_PF(id_proprietariopf) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Multa (
	id_multa INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    descricao VARCHAR(100),
    tipo ENUM ('leve','media','grave','gravissima') NOT NULL,
    fator ENUM ('2x','3x','5x','10x','20x','60x') NOT NULL,
    valor_atual DECIMAL NOT NULL,
    penalidade_pontos INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS Veiculo (
	id_veiculo INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    chassis VARCHAR(20) UNIQUE,
    numero_placa VARCHAR(8),
    numero_motor VARCHAR(10),
    renavam VARCHAR(11),
    ano_modelo VARCHAR(10),
    situacao ENUM ('em circulacao', 'apreendido', 'baixa'),
	cor VARCHAR(30),
    fk_cidade_id INT NOT NULL,
    fk_proprietario_id INT NOT NULL,
    fk_modelo_id INT NOT NULL,
    FOREIGN KEY (fk_cidade_id) REFERENCES Cidade(id_cidade),
    FOREIGN KEY (fk_proprietario_id) REFERENCES Proprietario(id_proprietario),
    FOREIGN KEY (fk_modelo_id) REFERENCES Modelo(id_modelo)
);

CREATE TABLE IF NOT EXISTS Aplicacao_multa (
	id_aplicacao_multa INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    data_multa DATE,
    horario TIME,
    longitude VARCHAR(30),
    latitude VARCHAR(30),
    valor_aplicado DECIMAL,
    fk_multa_id INT NOT NULL,
    fk_veiculo_id INT NOT NULL,
    fk_proprietarioPF_id INT NOT NULL,
    FOREIGN KEY (fk_multa_id) REFERENCES Multa(id_multa),
	FOREIGN KEY (fk_veiculo_id) REFERENCES Veiculo(id_veiculo),
    FOREIGN KEY (fk_proprietarioPF_id) REFERENCES Proprietario_PF(id_proprietariopf)
);



