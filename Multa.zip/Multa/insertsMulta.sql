/*Inserindo duas fodendo pessoas nessa porra*/

INSERT INTO Estado (nome,sigla,nome_pais) VALUES ('Rondônia','RO','Brasil');

INSERT INTO Cidade (nome,codigo_ibge,fk_estado_id) VALUES ('Jaru','1100122',1);
INSERT INTO Cidade (nome,codigo_ibge,fk_estado_id) VALUES ('Ji-Paraná','1100114',1);

INSERT INTO Endereco (cep,logradouro,bairro,numero,fk_cidade_id) VALUES ('76890-000','Rua Rio Branco','setor 01','1997',1);
INSERT INTO Endereco (cep,logradouro,bairro,numero,fk_cidade_id) VALUES ('76900-700','Rua 13 de setembro','jardim dos migrantes','589',1);

INSERT INTO Proprietario (email, telefone, fk_endereco_id) VALUES ('lucayanfelips@hotmail.com','45988249196','1');
INSERT INTO Proprietario_pf (nome,cpf,rg,data_nascimento,sexo) VALUES ('Lucayan Felipe','02514705207','13343789','2000-02-18','masculino');

INSERT INTO Proprietario (email, telefone, fk_endereco_id) VALUES ('WitchMochi@hotmail.com','69992992600','2');
INSERT INTO Proprietario_pf (nome,cpf,rg,data_nascimento,sexo) VALUES ('Alicy rodrigues','00607666200','16145436','2004-03-30','feminino');

INSERT INTO Marca (nome, observacao, localidade) VALUES ('FORD','carros fodas','Estados Unidos');
INSERT INTO Marca (nome, observacao, localidade) VALUES ('HYUNDAI','xingling','Coreia do Sul');
INSERT INTO Marca (nome, observacao, localidade) VALUES ('NISSAN','pan de quejo','Japao');

INSERT INTO marca (nome, observacao, localidade) VALUES
('Ford', 'Uma das mais antigas fabricantes de carros do mundo.', 'Estados Unidos'),
('Fiat', 'Conhecida por seus carros compactos e eficientes.', 'Itália'),
('Toyota', 'Líder global em vendas, focada em inovação e sustentabilidade.', 'Japão');

INSERT INTO modelo (descricao, qtd_eixos, peso, qtd_passageiros, cavalaria, cilindradas, fk_marca_id) VALUES
('Sedan Familiar', '2', 1500, 5, 110, 1600, 1),
('Compacto Urbano', '2', 800, 4, 80, 1000, 2),
('Esportivo', '2', 1200, 2, 200, 2000, 3),
('SUV 4x4', '4', 2000, 5, 150, 2200, 1);

INSERT INTO estado (nome, sigla, nome_pais) VALUES
('Acre', 'AC', 'Brasil'),
('Alagoas', 'AL', 'Brasil'),
('Amazonas', 'AM', 'Brasil'),
('Amapá', 'AP', 'Brasil'),
('Bahia', 'BA','Brasil'),
('Ceará', 'CE','Brasil'),
('Distrito Federal','UF','Brasil'),
('Espírito Santo','ES','Brasil'),
('Goiás', 'GO','Brasil'),
('Maranhão', 'MA','Brasil');


INSERT INTO cidade (nome, fk_estado_id, codigo_ibge) VALUES
('Afonso Cláudio', 8, 3200102),
('Água Doce do Norte', 8, 3200169),
('Águia Branca', 8, 3200136),
('Alegre', 8, 3200201),
('Alfredo Chaves', 8, 3200300),
('Alto Rio Novo', 8, 3200359),
('Anchieta', 8, 3200409),
('Apiacá', 8, 3200508),
('Aracruz', 8, 3200607),
('Atilio Vivacqua', 8, 3200706);


INSERT INTO endereco (cep, logradouro, bairro, numero, fk_cidade_id) VALUES
('01000-000', 'Avenida Paulista', 'Bela Vista', '1000', 1),
('02000-000', 'Avenida Paulista', 'Jardim Dos Migrantes', '1001', 3),
('03000-000', 'Avenida Paulista', 'Bela Vista', '1002', 9);


INSERT INTO proprietario (email, telefone, fk_endereco_id) VALUES
('proprietario2@example.com', '21999999999', 1),
('proprietario3@example.com', '31999999999', 2),
('proprietario4@example.com', '41999999999', 3),
('proprietario5@example.com', '51999999999', 2),
('proprietario6@example.com', '61999999999', 1);


INSERT INTO veiculo (chassis, numero_placa, numero_motor, renavam, ano_modelo, situacao, cor, fk_modelo_id, fk_proprietario_id, fk_cidade_id)
VALUES
('1e68b3Ybn6rAb6153', 'XYZ1234', '1.6 VVT', '12345678901', '2019', 'Ativo', 'Prata', 1, 1, 1),
('78t1AW6FbWh9Z7455', 'ABC5678', '2.0 TDI', '23456789012', '2020', 'Ativo', 'Preto', 1, 5, 8),
('19t cHAA3A cz GA8316', 'DEF1234', '1.8 TFSI', '34567890123', '2018', 'Ativo', 'Azul', 1, 2, 4),
('30T 4sEXkb AW 9k2095', 'GHI5678', '2.5 SFI', '45678901234', '2021', 'Ativo', 'Vermelho', 3, 1, 6),
('8AX 23GEA5 1s j25905', 'JKL1234', '1.4 Turbo', '56789012345', '2017', 'Ativo', 'Verde', 1, 2, 10),
('1mN c0248R AD 6p3948', 'MNO5678', '3.0 V6', '67890123456', '2022', 'Ativo', 'Amarelo', 1, 1, 7),
('2Ry vD6z4g 49 ZJ5820', 'PQR1234', '4.0 V8', '78901234567', '2015', 'Ativo', 'Branco', 1, 2, 2),
('26A A7NCSA P8 Yc1186', 'STU5678', '2.2 HDi', '89012345678', '2016', 'Ativo', 'Cinza', 2, 3, 1),
('2UW X6mMWB 9L T56320', 'VWX1234', '3.5 EcoBoost', '90123456789', '2023', 'Ativo', 'Laranja', 3, 4, 6),
('88V TndK4D nj es0001', 'YZA5678', '2.4 GDI', '01234567890', '2014', 'Ativo', 'Roxo', 1, 5, 9),
('4HGBH41JXMN109186', 'BCD2345', '1.3 Hybrid', '09876543211', '2024', 'Ativo', 'Marrom', 2, 4, 3),
('5FNYF4H90FB018187', 'CDE3456', '2.0 BiTurbo', '98765432102', '2022', 'Ativo', 'Magenta', 3, 3, 1),
('6G1MK5U22BL637188', 'DEF4567', '1.5 Electric', '87654321093', '2021', 'Ativo', 'Turquesa', 1, 2, 5),
('7HKRM4H50CU541189', 'EFG5678', '2.7 V6 TT', '76543210984', '2019', 'Ativo', 'Ouro', 2, 5, 4),
('8JH4DB16513001990', 'FGH6789', '3.8 V8', '65432109875', '2020', 'Ativo', 'Prata', 3, 5, 4),
('9KL8M3H72EC002191', 'GHI7890', '4.0 V12', '54321098766', '2023', 'Ativo', 'Preto', 1, 1, 5),
('1M8GDM9AXKP042192', 'HIJ8901', '1.2 TSI', '43210987657', '2022', 'Ativo', 'Azul', 2, 3, 3),
('2N6RD7AT5EC011193', 'IJK9012', '2.5 TFSI', '32109876548', '2018', 'Ativo', 'Vermelho', 3, 4, 2),
('3P3E9CCG1NT026194', 'JKL0123', '1.6 GDi', '21098765439', '2017', 'Ativo', 'Verde', 1, 1, 4),
('4S4BP61C797132195', 'KLM1234', '3.0 TDI', '10987654320', '2021', 'Ativo', 'Amarelo', 2, 1, 5);



/*cadastrar 20 veiculos com 3 marcas diferentes*/
/*
[21:50, 02/04/2024] +55 69 9242-2256: tai, todas as cidades
[21:56, 02/04/2024] +55 69 9242-2256: CREATE TABLE estados (
  id_estado int NOT NULL PRIMARY KEY AUTO_INCREMENT,
  nome_est varchar(75) DEFAULT NULL,
  uf_est varchar(2) DEFAULT NULL,
  ibge_est int DEFAULT NULL,
  pais_est int DEFAULT NULL,
  ddd_est varchar(50) DEFAULT NULL
)  COMMENT='Unidades Federativas';
 

 
CREATE TABLE cidades (
  id_cidade int NOT NULL primary key auto_increment,
  nome_cid varchar(120) DEFAULT NULL,
  ibge_cid int DEFAULT NULL,
  fk_id_estado int DEFAULT NULL,
  FOREIGN KEY (fk_id_estado) REFERENCES estados (id_estado)
);
*/